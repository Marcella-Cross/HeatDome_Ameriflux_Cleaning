function folderSites = biomet_sites_default
% This file is generated automatically by set_TAB_project('/Users/mcross/Desktop/FluxProjectPipeline/MicroMet/Projects/My_Micromet/')
folderSites = '/Users/mcross/Desktop/FluxProjectPipeline/MicroMet/Projects/My_Micromet/Sites';
