function folderDatabase = biomet_database_default
% This file is generated automatically by set_TAB_project.m('/Users/mcross/Desktop/FluxProjectPipeline/MicroMet/Projects/My_Micromet/')
folderDatabase = '/Users/mcross/Desktop/FluxProjectPipeline/MicroMet/Projects/My_Micromet/Database';
